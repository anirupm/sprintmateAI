# SprintMate AI

**SprintMate AI** is a capstone project for the **Agents for Business** track. It is a multi-agent project planning assistant that converts a rough software/product idea into a structured project planning draft.

Instead of using one generic chatbot, SprintMate AI breaks the work into specialized agents:

1. Requirement Analyst Agent
2. Feature Planner Agent
3. Technical Advisor Agent
4. Security & Risk Agent
5. Final Report Agent

The output includes project summary, target users, business goals, feature list, user stories, technical approach, security checklist, risks, and sprint-wise planning.

---

## Project Theme

**Track:** Agents for Business  
**Project Name:** SprintMate AI  
**Use Case:** Early-stage software project planning for business and engineering teams

---

## Problem Statement

Software teams often begin with rough project ideas such as:

```text
I want to build an AI-powered leave management system for a mid-sized company.
```

This kind of input is not enough for development. Teams still need requirements, user stories, acceptance criteria, MVP scope, technical choices, risks, and sprint tasks. SprintMate AI helps create a structured first draft so that a team can review and improve it instead of starting from a blank page.

---

## Solution Overview

SprintMate AI uses a sequential multi-agent workflow. Each agent receives the previous agent's output and adds a focused layer of planning.

```mermaid
flowchart LR
    A[User Project Idea] --> B[Requirement Analyst Agent]
    B --> C[Feature Planner Agent]
    C --> D[Technical Advisor Agent]
    D --> E[Security & Risk Agent]
    E --> F[Final Report Agent]
    F --> G[Structured Sprint Plan]
```

---

## Architecture

```text
sprintmate-ai-capstone/
│
├── README.md
├── main.py
├── requirements.txt
├── sample_input.txt
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   ├── requirement_agent.py
│   ├── feature_agent.py
│   ├── technical_agent.py
│   ├── security_agent.py
│   └── report_agent.py
│
├── tools/
│   ├── __init__.py
│   ├── effort_estimator.py
│   ├── feature_prioritizer.py
│   └── security_checker.py
│
├── outputs/
│   └── sample_output.md
│
└── media/
    └── architecture.md
```

---

## Course Concepts Demonstrated

### 1. Multi-Agent System

SprintMate AI uses multiple specialized agents rather than one general-purpose assistant.

### 2. Sequential Agent Workflow

The system follows a pipeline where each agent builds on the output of the previous agent.

### 3. Agent Skills / Tools

The agents use custom tools for feature prioritization, effort estimation, and security checks.

### 4. MCP-Style Tool Layer

The tool functions are separated from the agents. This is inspired by an MCP-style design where tools are exposed as structured capabilities that agents can call.

### 5. Security Considerations

A dedicated Security & Risk Agent reviews the generated plan and adds authentication, authorization, privacy, data handling, and prompt safety recommendations.

---

## How to Run

### Option 1: Run with the default sample idea

```bash
python main.py
```

This uses the default input from `sample_input.txt` and writes the generated plan to:

```text
outputs/generated_sprint_plan.md
```

### Option 2: Run with your own project idea

```bash
python main.py "I want to build an AI-powered study planner for college students."
```

### Option 3: Run and provide a custom output file

```bash
python main.py "I want to build a customer support chatbot for a small business." --output outputs/customer_support_plan.md
```

---

## Requirements

This project intentionally uses only the Python standard library so that it can run easily on Kaggle Notebook, local machines, or GitHub Codespaces.

Recommended Python version:

```text
Python 3.10+
```

Install step:

```bash
pip install -r requirements.txt
```

Note: `requirements.txt` is currently empty because there are no external dependencies.

---

## Sample Input

```text
I want to build an AI-powered leave management system for a mid-sized company.
```

---

## Sample Output Preview

The generated output includes sections like:

```text
# SprintMate AI Generated Project Plan

## 1. Requirement Analysis
- Problem summary
- Target users
- Business goals
- Assumptions
- Constraints

## 2. Feature Plan
- MVP features
- User stories
- Acceptance criteria
- Priority

## 3. Technical Plan
- Suggested architecture
- Data model ideas
- Integration points
- Deployment approach

## 4. Security & Risk Review
- Authentication and authorization
- Sensitive data handling
- Prompt safety
- Operational risks

## 5. Sprint Roadmap
- Sprint 1
- Sprint 2
- Sprint 3
```

A complete sample is available at:

```text
outputs/sample_output.md
```

---

## Design Choice

The current version uses rule-based agent logic so that the project can be executed without paid API keys. The structure is intentionally designed so that an LLM call can be added later inside each agent's `run()` method.

This keeps the capstone easy to run while still clearly demonstrating agent design, tool usage, orchestration, and security review.

---

## Future Improvements

- Add Google ADK-based orchestration
- Connect to Gemini or another LLM provider
- Expose tools through a real MCP server
- Integrate with Jira or GitHub Issues
- Add memory for team-specific estimation preferences
- Add a UI using Streamlit or Gradio
- Add evaluation scoring for generated plans

---

## Author

**Anirup Mukherjee**
