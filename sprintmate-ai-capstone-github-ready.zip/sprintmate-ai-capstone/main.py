import argparse
from pathlib import Path
from typing import Dict, Any

from agents.requirement_agent import RequirementAnalystAgent
from agents.feature_agent import FeaturePlannerAgent
from agents.technical_agent import TechnicalAdvisorAgent
from agents.security_agent import SecurityRiskAgent
from agents.report_agent import FinalReportAgent


DEFAULT_OUTPUT = "outputs/generated_sprint_plan.md"
SAMPLE_INPUT_FILE = "sample_input.txt"


def load_default_project_idea() -> str:
    sample_path = Path(SAMPLE_INPUT_FILE)
    if sample_path.exists():
        return sample_path.read_text(encoding="utf-8").strip()
    return "I want to build an AI-powered leave management system for a mid-sized company."


def run_sprintmate(project_idea: str) -> str:
    """Run the sequential multi-agent planning workflow."""
    context: Dict[str, Any] = {"project_idea": project_idea}

    requirement_agent = RequirementAnalystAgent()
    feature_agent = FeaturePlannerAgent()
    technical_agent = TechnicalAdvisorAgent()
    security_agent = SecurityRiskAgent()
    report_agent = FinalReportAgent()

    requirement_result = requirement_agent.run(context)
    context["requirement_analysis"] = requirement_result.output

    feature_result = feature_agent.run(context)
    context["feature_plan"] = feature_result.output

    technical_result = technical_agent.run(context)
    context["technical_plan"] = technical_result.output

    security_result = security_agent.run(context)
    context["security_review"] = security_result.output

    report_result = report_agent.run(context)
    return report_result.output["markdown_report"]


def main() -> None:
    parser = argparse.ArgumentParser(description="SprintMate AI - Multi-Agent Project Planning Assistant")
    parser.add_argument("project_idea", nargs="?", default=None, help="Project idea to convert into a sprint plan")
    parser.add_argument("--output", default=DEFAULT_OUTPUT, help="Path to write the generated markdown report")
    args = parser.parse_args()

    project_idea = args.project_idea or load_default_project_idea()
    report = run_sprintmate(project_idea)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(report, encoding="utf-8")

    print("SprintMate AI completed successfully.")
    print(f"Output written to: {output_path}")


if __name__ == "__main__":
    main()
