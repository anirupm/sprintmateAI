# SprintMate AI Architecture

```mermaid
flowchart TD
    A[User Project Idea] --> B[Requirement Analyst Agent]
    B --> C[Feature Planner Agent]
    C --> D[Technical Advisor Agent]
    D --> E[Security & Risk Agent]
    E --> F[Final Report Agent]
    F --> G[Structured Sprint Plan]

    C -. uses .-> T1[Feature Prioritizer Tool]
    C -. uses .-> T2[Effort Estimator Tool]
    E -. uses .-> T3[Security Checker Tool]
```
