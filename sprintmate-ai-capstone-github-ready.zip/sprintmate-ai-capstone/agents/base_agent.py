from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class AgentResult:
    """Standard response object returned by every agent."""

    agent_name: str
    output: Dict[str, Any]


class BaseAgent:
    """Base class for all SprintMate AI agents."""

    name = "Base Agent"

    def run(self, context: Dict[str, Any]) -> AgentResult:
        raise NotImplementedError("Each agent must implement its own run method.")
