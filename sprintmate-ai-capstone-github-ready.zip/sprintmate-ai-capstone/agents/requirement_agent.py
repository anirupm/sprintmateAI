from typing import Any, Dict
from .base_agent import BaseAgent, AgentResult


class RequirementAnalystAgent(BaseAgent):
    name = "Requirement Analyst Agent"

    def run(self, context: Dict[str, Any]) -> AgentResult:
        idea = context["project_idea"].strip()

        output = {
            "problem_summary": (
                f"The proposed project idea is: '{idea}'. The solution needs to convert this idea "
                "into a practical product plan that can be reviewed by business and engineering teams."
            ),
            "target_users": [
                "Business stakeholders",
                "Product owners or business analysts",
                "Development team members",
                "Project managers or scrum masters",
            ],
            "business_goals": [
                "Create a clear first draft from an informal idea.",
                "Reduce repeated clarification during early planning.",
                "Improve alignment between business and technical teams.",
            ],
            "assumptions": [
                "The user is describing a small to medium software project.",
                "The output will be reviewed by humans before real implementation.",
                "The first version should focus on MVP planning rather than full enterprise rollout.",
            ],
            "constraints": [
                "Generated outputs are planning drafts, not final business approvals.",
                "Sensitive business or personal data should not be entered into the prompt.",
            ],
        }
        return AgentResult(agent_name=self.name, output=output)
