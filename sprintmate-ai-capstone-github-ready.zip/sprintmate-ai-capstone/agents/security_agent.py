from typing import Any, Dict
from .base_agent import BaseAgent, AgentResult
from tools.security_checker import generate_security_checklist


class SecurityRiskAgent(BaseAgent):
    name = "Security & Risk Agent"

    def run(self, context: Dict[str, Any]) -> AgentResult:
        project_idea = context["project_idea"]
        features = context["feature_plan"]["mvp_features"]
        security_review = generate_security_checklist(project_idea, features)

        security_review["human_review_guidance"] = [
            "Treat generated output as a planning draft.",
            "Ask a product owner or domain expert to validate business assumptions.",
            "Ask a technical reviewer to validate architecture choices.",
            "Ask a security reviewer to validate privacy and compliance points before production use.",
        ]
        return AgentResult(agent_name=self.name, output=security_review)
