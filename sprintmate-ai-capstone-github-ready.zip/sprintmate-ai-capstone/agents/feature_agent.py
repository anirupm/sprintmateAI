from typing import Any, Dict, List
from .base_agent import BaseAgent, AgentResult
from tools.feature_prioritizer import prioritize_features
from tools.effort_estimator import estimate_effort


class FeaturePlannerAgent(BaseAgent):
    name = "Feature Planner Agent"

    def run(self, context: Dict[str, Any]) -> AgentResult:
        idea = context["project_idea"].lower()

        features: List[Dict[str, str]] = [
            {"name": "User onboarding", "description": "Allow users to access the system based on their role."},
            {"name": "Dashboard", "description": "Show the most important project or workflow information in one place."},
            {"name": "Request creation", "description": "Allow users to create and submit a new request or project item."},
            {"name": "Approval workflow", "description": "Support review and approval by the correct responsible person."},
            {"name": "Notifications", "description": "Notify users when an item is submitted, updated, or approved."},
            {"name": "Reports and analytics", "description": "Provide summary reports for decision-making."},
        ]

        if "ai" in idea:
            features.insert(2, {"name": "AI-assisted recommendations", "description": "Generate draft suggestions that users can review and refine."})

        if "leave" in idea:
            features.extend([
                {"name": "Leave balance tracking", "description": "Show available, used, and pending leave balances."},
                {"name": "Holiday calendar", "description": "Display holidays and non-working days for planning."},
            ])

        prioritized = prioritize_features(features)
        estimates = [estimate_effort(item["name"], item["priority"]) for item in prioritized]

        user_stories = [
            {
                "story": f"As a user, I want to use {feature['name'].lower()} so that {feature['description'].lower()}",
                "acceptance_criteria": [
                    "The feature should be accessible only to authorized users.",
                    "The user should receive clear feedback after completing the action.",
                    "Errors should be handled with readable messages.",
                ],
                "priority": feature["priority"],
            }
            for feature in prioritized[:6]
        ]

        output = {
            "mvp_features": prioritized,
            "effort_estimates": estimates,
            "user_stories": user_stories,
        }
        return AgentResult(agent_name=self.name, output=output)
