from typing import Dict, List


def prioritize_features(features: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """Assign a simple priority label to each feature.

    This is intentionally lightweight and explainable for capstone review.
    A future version can replace this with historical project data or LLM reasoning.
    """
    prioritized = []
    for index, feature in enumerate(features):
        item = dict(feature)
        if index < 3:
            item["priority"] = "High"
        elif index < 5:
            item["priority"] = "Medium"
        else:
            item["priority"] = "Low"
        prioritized.append(item)
    return prioritized
