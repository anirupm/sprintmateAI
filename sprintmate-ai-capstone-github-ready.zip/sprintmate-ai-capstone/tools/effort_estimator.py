from typing import Dict


def estimate_effort(feature_name: str, priority: str) -> Dict[str, str]:
    """Estimate effort using a simple rule-based approach."""
    lower_name = feature_name.lower()

    if any(keyword in lower_name for keyword in ["ai", "approval", "integration", "analytics", "security"]):
        complexity = "High"
        points = "8"
    elif priority == "High":
        complexity = "Medium"
        points = "5"
    else:
        complexity = "Low"
        points = "3"

    return {
        "feature": feature_name,
        "complexity": complexity,
        "story_points": points,
    }
