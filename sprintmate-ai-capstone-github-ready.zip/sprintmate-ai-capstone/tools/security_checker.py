from typing import Dict, List


def generate_security_checklist(project_idea: str, features: List[Dict[str, str]]) -> Dict[str, List[str]]:
    """Generate practical security and privacy checks for the project plan."""
    feature_text = " ".join(feature["name"].lower() for feature in features)
    idea_text = project_idea.lower()
    combined = f"{idea_text} {feature_text}"

    checklist = [
        "Use authentication for all user-specific workflows.",
        "Apply role-based authorization for admin, manager, and employee actions.",
        "Validate all user inputs before storing or processing data.",
        "Avoid asking users to paste confidential company data into prompts.",
        "Log important actions without storing sensitive personal data in plain text.",
        "Keep a human review step before using generated project plans for real delivery.",
    ]

    if "leave" in combined or "employee" in combined or "hr" in combined:
        checklist.append("Treat employee leave records as sensitive HR data and restrict access by role.")

    if "ai" in combined:
        checklist.append("Add prompt-injection protection and clearly label AI-generated suggestions as drafts.")

    if "analytics" in combined or "report" in combined:
        checklist.append("Aggregate analytics where possible to avoid exposing individual-level sensitive data.")

    risks = [
        "Generated plans may contain assumptions that require human validation.",
        "Incorrect role permissions can expose sensitive business data.",
        "Over-reliance on AI output can lead to weak requirement review.",
    ]

    return {
        "security_checklist": checklist,
        "risks": risks,
    }
